/**
 * 
 */

function validate() {
	// alert("Inside validate");
	document.getElementById("errormessageUsername").innerHTML = "";
	var UsernameHasError = false;
	if (document.register.username.value.length == 0) {
		document.getElementById("errormessageUsername").innerHTML = "<font color=\"red\" size = \"1px\">You need to put in a username.</font><br />";
		UsernameHasError = true;
	}

	var PasswordHasError = false;
	if (document.register.password.value.length == 0) {
		document.getElementById("errormessagePassword").innerHTML = "<font color=\"red\" size = \"1px\">You need to put in a password.</font><br />";
		PasswordHasError = true;
	}

	var ConfirmPasswordhasError = false;
	if (document.register.confirmpassword.value.length == 0) {
		document.getElementById("errormessageConfirmPassword").innerHTML = "<font color=\"red\" size = \"1px\">You need to comfirm your password.</font><br />";
		ConfirmPasswordhasError = true;
	}

	var match = false;
	if(document.register.confirmpassword.value != document.register.password.value){
		alert("not match");
		document.getElementById("errormessageConfirmPassword").innerHTML = "<font color=\"red\" size = \"1px\">Your comfirm password does\n not match your original password.</font><br />";
		match = true;
	}

	return (!UsernameHasError  && !PasswordHasError && !ConfirmPasswordhasError && !match);
}