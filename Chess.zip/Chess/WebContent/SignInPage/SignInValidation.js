/**
 * 
 */
function validate() {
	document.getElementById("errormessageUsername").innerHTML = "";
	if (document.form.username.value.length == 0) {
		document.getElementById("errormessageUsername").innerHTML = "<font color=\"red\" size = \"1px\">You need to put in a username.</font><br/>";
		UsernameHasError = true;
	}

	var PasswordHasError = false;
	if (document.form.password.value.length == 0) {
		document.getElementById("errormessagePassword").innerHTML = "<font color=\"red\" size = \"1px\">You need to put in a password.</font><br/>";
		PasswordHasError = true;
	}

	return !UsernameHasError && !PasswordHasError;
}