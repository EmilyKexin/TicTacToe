

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class database_methods{
	final static String USER = "root";
	final static String PASS = "5739240258076";
	
	static void CreateTable() throws ClassNotFoundException {
		final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
		final String DB_URL = "jdbc:mysql://localhost/";
		final String TIME_ZONE = "&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC";
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		String databaseName = "PACSNAKEDB";
		
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL+"?user="+USER+"&password="+PASS+"&allowPublicKeyRetrieval=true" + TIME_ZONE);
			
			Boolean databaseExist = false;
			ResultSet resultSet = conn.getMetaData().getCatalogs();
	        while (resultSet.next()) {
	        	if(databaseName.equals(databaseName)){
	        		databaseExist = true;
	            }
	        }
	        if(!databaseExist) {
		        System.out.println("Drop successfully");
				String sqlCreate = "CREATE DATABASE PACSNAKEDB;";
				PreparedStatement stmt = conn.prepareStatement(sqlCreate);
				stmt.execute();
	        }
			System.out.println("Database created successfully...");
			if(conn != null) {
				conn.close();
			}
			
			Connection new_conn = DriverManager.getConnection(DB_URL + databaseName + "?user="+USER+"&password="+PASS+"&allowPublicKeyRetrieval=true" + TIME_ZONE);
			
			Boolean tableExists = false;
			ResultSet dbm = new_conn.getMetaData().getTables(null, null, "USERS", null);
			if (dbm.next()) {
				tableExists = true;
			}
			
			if(!tableExists) {
				String newSql = "CREATE TABLE USERS("
						+ " USER_ID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,"
						+ "USERNAME VARCHAR(50) NOT NULL,"
						+ "PASSWORD VARCHAR(50) NOT NULL);";
				PreparedStatement stmt = new_conn.prepareStatement(newSql);
				stmt.execute();
			}

			System.out.println("Table created");
		}catch(SQLException se) {
			System.out.println("sqle: " + se.getMessage());
		}finally {
			try{
				if(st!=null)
					st.close();
			}catch(SQLException se2){
				
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		
	}
	
	static String insertUser(String username, String password) throws ClassNotFoundException {
		String result = null;
		final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
		final String DB_URL = "jdbc:mysql://localhost/";
		final String TIME_ZONE = "&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC";
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		String databaseName = "PACSNAKEDB";
		
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to database...");
			Connection new_conn = DriverManager.getConnection(DB_URL + databaseName + "?user="+USER+"&password="+PASS+"&allowPublicKeyRetrieval=true" + TIME_ZONE);
			String newSql = "SELECT * FROM USERS WHERE USERNAME=?";
			PreparedStatement stmt = new_conn.prepareStatement(newSql);
			stmt.setString(1, username);
			rs = stmt.executeQuery();
			if(rs.next()) {
				result = "User Exist";
			}
			else {
				result = "User Not Exist";
			}
			
			if(result.equals("User Not Exist")) {
				newSql = "INSERT INTO USERS(USERNAME,PASSWORD) VALUES(?,?)";
				stmt = new_conn.prepareStatement(newSql);
				stmt.setString(1, username);
				stmt.setString(2, password);
				int affectedRows = stmt.executeUpdate();
				if(affectedRows > 0) {
					result = "successfully created user";
				}
			}
		}catch(SQLException se) {
			System.out.println("sqle: " + se.getMessage());
		}finally {
			try{
				if(st!=null)
					st.close();
			}catch(SQLException se2){
				
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		System.out.println(result);
		return result;
	}
	
	static String VarifyUser(String username, String password) throws ClassNotFoundException {
		String result = null;
		final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
		final String DB_URL = "jdbc:mysql://localhost/";
		final String TIME_ZONE = "&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC";
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		String databaseName = "PACSNAKEDB";
		
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to database...");
			Connection new_conn = DriverManager.getConnection(DB_URL + databaseName + "?user="+USER+"&password="+PASS+"&allowPublicKeyRetrieval=true" + TIME_ZONE);
			String newSql = "SELECT * FROM USERS WHERE USERNAME=?";
			PreparedStatement stmt = new_conn.prepareStatement(newSql);
			stmt.setString(1, username);
			rs = stmt.executeQuery();
			if(rs.next()) {
				String storedPass = rs.getString("password");
				if(storedPass.equals(password)) {
					result = "User Exist";
				}
				else {
					result = "Password does not match";
				}
			}
			else {
				result = "User Not Exist";
			}
		}catch(SQLException se) {
			System.out.println("sqle: " + se.getMessage());
		}finally {
			try{
				if(st!=null)
					st.close();
			}catch(SQLException se2){
				
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		System.out.println(result);
		return result;
	}


}
