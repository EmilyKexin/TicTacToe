

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class home_page_to_tic
 */
@WebServlet("/home_page_to_tic")
public class home_page_to_tic extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public home_page_to_tic() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = (String) request.getAttribute("username");
		System.out.println("username: " + username);
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>\n" + 
				"<html>\n" + 
				"<head>\n" + 
				"	<title>Welcome to PacWorld!" + username + "</title>\n" + 
				"	<link rel=\"stylesheet\" type=\"text/css\" href=\"/Chess/HomePage/homepage.css\">\n" + 
				"</head>\n" + 
				"<body>");
		
		out.println("	<div class = \"title\" name=\"username\">" + username + "pacsnake</div>\n" + 
				"	<div class = \"container\">\n" + 
				"		<div class = \"Red\">\n" + 
				"			<a class=\"gameLink\" href= /Chess/tic_tac_toe.jsp?username=" + username + ">Tic Pac Toe</a><br/>\n" + 
				"			<a href=\"https://www.w3docs.com/\" class=\"gameLink\">Pac Snake</a>\n" + 
				"		</div>\n" + 
				"\n" + 
				"		<form class = \"bottom\" method = \"GET\" action = \"/Chess/HighestScorePage/HighestScore.jsp\" >\n" + 
				"			<img src=\"/Chess/assets/images/highestScore.png\">\n" + 
				"			<input type = \"submit\" class = \"text\" value = \"VIEW HIGHEST SCORES\">\n" + 
				"		</form>\n" + 
				"	</div>");
		
		out.println("</body>\n" + 
				"</html>");
		
//		request.setAttribute("username",username);
//		System.out.println("From home page to tic game: " + username);
//		request.getRequestDispatcher("tic_tac_toe.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
