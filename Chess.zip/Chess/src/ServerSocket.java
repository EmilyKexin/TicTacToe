import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;





@ServerEndpoint(value = "/ws")

public class ServerSocket {
	Session mSession;
	
	//Save the user name and each move the user have made
	static HashMap<String, Vector<Integer>> user_moves = null;
	
	//Associate user with color
	static Map<String, String> user_color = (Map<String, String>) Collections.synchronizedMap(new HashMap<String, String>());
	
	private static Vector<Session> sessionVector = new Vector<Session>();
	@OnOpen
	public void open(Session session) {
		System.out.println("Connection make!");
		sessionVector.add(session);
		
		mSession = session;
		
		//If the user has not made any move, create a new vector to store all the moves
		if(user_moves == null) {
			user_moves = new HashMap<String, Vector<Integer>>();
		}
	}
	
	
	@OnMessage
	public void onMessage(String message, Session session) {
		//The message send from client to the server is in the pattern of "user_name;move_made"
		System.out.println(message);
		String[] messages = message.split(";");
		String username = messages[0];
		String move = messages[1];
		Integer move_int = Integer.parseInt(move);
		System.out.println(messages[0] + "arrived!");
		
		//If the user has not been associated with a color, do it
		if(user_color == null || user_color.size() == 0) {
			System.out.println(username + " blue_cross");
			user_color = new HashMap<String, String>();
			user_color.put(username, "blue_cross");
			//System.out.println(user_color.toString());
		}
		else if(user_color.size() == 1) {
			if(user_color.get(username) == null || user_color.get(username) == "") {
				System.out.println(username + " red_circle");
				user_color.put(username, "red_circle");		
				//System.out.println(user_color.toString());
			}

		}
		System.out.println(user_color.toString());
		//if the vector storing moves of the user has not be initiated, initiated it
		//And then add the move to the vector
		if(user_moves.get(username) == null) {
			Vector<Integer> moves = new Vector<Integer>();
			user_moves.put(username, moves);
			user_moves.get(username).add(move_int);
		}
		else {
			user_moves.get(username).add(move_int);
		}
		
		//Check if user has win the game
		Boolean win = check_if_win(user_moves.get(username));
		
		if(win) {
			//If the user has won, tell each other users who won
			try {
				for(Session s : sessionVector) {
					s.getBasicRemote().sendText(messages[0] + "has won!");
				}
			}catch(IOException ie) {
				System.out.println("IOE" + ie);
				close(session);
			}
		}
		else {
			//If the user has not won yet, send message to change the board on each client's side
			//the messages sending out are in the pattern of "user_name, color, move_made"
			try {
				for(Session s : sessionVector) {
					System.out.println(user_moves.get(username));
					s.getBasicRemote().sendText(messages[0] + "," + user_color.get(username) + "," + move);
				}
			}catch(IOException ie) {
				System.out.println("IOE" + ie);
				close(session);
			}
		}
	}
	
	@OnClose
	public void close(Session session) {
		//Clear everything in case the data is cached in server and browser
		user_moves.clear();
		user_color.clear();
		System.out.println("Disconnecting");
		sessionVector.remove(session);
	}
	
	@OnError
	public void error(Throwable error) {
		System.out.println("Error!");
	}
	
	private Boolean check_if_win(Vector<Integer> moves) {
		if(moves.contains(1) && moves.contains(2) && moves.contains(3)) {
			return true;
		}
		else if(moves.contains(4) && moves.contains(5) && moves.contains(6)) {
			return true;
		}
		else if(moves.contains(7) && moves.contains(8) && moves.contains(9)) {
			return true;
		}
		else if(moves.contains(1) && moves.contains(4) && moves.contains(7)) {
			return true;
		}
		else if(moves.contains(2) && moves.contains(5) && moves.contains(8)) {
			return true;
		}
		else if(moves.contains(3) && moves.contains(6) && moves.contains(9)) {
			return true;
		}
		else if(moves.contains(1) && moves.contains(5) && moves.contains(9)) {
			return true;
		}
		else if(moves.contains(3) && moves.contains(5) && moves.contains(7)) {
			return true;
		}
		return false;
	}
}
