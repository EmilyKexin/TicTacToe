

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class varify_sign_up
 */
@WebServlet("/varify_sign_up")
public class varify_sign_up extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public varify_sign_up() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String result;
		try {
			database_methods.CreateTable();
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			result = database_methods.insertUser(username, password);
			
			if(result.equals("User Exist")) {
				request.setAttribute("errUser", "This username already exists.");
				request.getRequestDispatcher("/SignUpPage/SignUpPage.jsp").forward(request, response);
			}
			else if(result.equals("successfully created user")) {
				request.getRequestDispatcher("/home_page_to_tic").forward(request, response);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
