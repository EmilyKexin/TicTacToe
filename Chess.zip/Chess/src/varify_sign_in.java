
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VarifySignIn
 */
@WebServlet("/varify_sign_in")
public class varify_sign_in extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public varify_sign_in() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String result = "";
		String username = null;
		try {
			username = request.getParameter("username");
			String password = request.getParameter("password");
			database_methods.CreateTable();
			result = database_methods.VarifyUser(username, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(result.equals("User Exist")) {
			request.setAttribute("username", username);
			request.getRequestDispatcher("home_page_to_tic").forward(request, response);
		}else if(result.equals("Password does not match")) {
			request.setAttribute("errPass", "Your password is not correct.");
			request.getRequestDispatcher("/SignInPage/SignInPage.jsp").forward(request, response);
		}else if(result.equals("User Not Exist")) {
			request.setAttribute("errPass", "This username has not been registered.");
			request.getRequestDispatcher("/SignInPage/SignInPage.jsp").forward(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
